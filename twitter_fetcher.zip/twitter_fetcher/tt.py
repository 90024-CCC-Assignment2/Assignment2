for j in range(5):
  print(j)
